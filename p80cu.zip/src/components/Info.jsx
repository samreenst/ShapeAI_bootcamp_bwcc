import React from "react";

function Info() {
  return (
    <div className="note">
      <h1>JavaScript and React.js</h1>
      <p> A basic Web development React Js Bootcamp</p>
    </div>
  );
}
export default Info;
